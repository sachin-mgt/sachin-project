<?php
 namespace Mgt\Varnish\Model\Logger; class Handler extends \Magento\Framework\Logger\Handler\Base { const DEBUG = 100; protected $loggerType = 100; protected $fileName = "\57\x76\141\x72\x2f\x6c\157\147\x2f\155\x67\164\x5f\166\x61\x72\156\151\163\x68\56\154\157\x67"; }
