<?php
 \Magento\Framework\Component\ComponentRegistrar::register(\Magento\Framework\Component\ComponentRegistrar::MODULE, "\115\x67\x74\137\126\x61\162\156\151\163\150", __DIR__);
